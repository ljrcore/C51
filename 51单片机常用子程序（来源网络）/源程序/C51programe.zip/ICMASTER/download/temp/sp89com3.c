/*P89CXX ��������Է��ͳ���*/
#include "stdio.h"
#include "dos.h"
#include "process.h"
#include "string.h"
#include "time.h"

float start_time;
FILE *fp1;


#define b_init 0

#define b_erase 1
#define b_erase_block 2				/*P89C51RC+��P89C51RD+����*/
#define b_erase_sbyte_bvec 3		/*P89C51RC+��P89C51RD+����*/

#define b_read 4

#define b_program_byte 5
#define b_program_sbyte 6			/*P89C51RC+��P89C51RD+����*/
#define b_program_boot_vector 7		/*P89C51RC+��P89C51RD+����*/

#define b_lock1 8
#define b_lock12 9
#define b_lock123 10

#define b_cpu 12					/*������Ҫ��̵�cpu����,0:P89C51 1:P89C52 2:P89C54 3:P89C58 4:P89C51RC+ 5:P89C51RD+*/


unsigned char *cpu_d[]={{"P89C51U"},{"P89C52U"},{"P89C54U"},{"P89C58U"},{"P89C51RC+"},{"P89C51RD+"}};


void init_com3(void) {
	outportb(0x3eb,0x80);
	outportb(0x3e8,1);
	outportb(0x3e9,0x0);
	outportb(0x3eb,0x3);
}
void sen_com3(unsigned char d) {
	long i;
	while (!(inportb(0x3ed)&0x20));
	outportb(0x3ed,0x0);
	outportb(0x3e8,d);
	i=clock();
	while (1) {
		if (clock()>(i+9)) {clrscr();printf("Time out.\n\7\7");exit(1);}
		if ((inp(0x3ed)&0x1)==1) break;
	}
	if (inp(0x3e8)!=d) {clrscr();printf("CRC error.\n");exit(1);}
}
unsigned char rec_com3(void) {
	long i;
	unsigned char d;
	i=clock();
	while (1) {
		if (clock()>(i+9)) {printf("Time out.\n\7\7");exit(1);}
		if ((inp(0x3ed)&1)==1) break;
	}
	d=inp(0x3e8);
	while (!(inportb(0x3ed)&0x20));
	outportb(0x3ed,0x0);
	outportb(0x3e8,d);
	return(d);
}
/*�ȴ���ʱʱ��Ƚϳ�,5��*/
unsigned char rec_com3_long(void) {
	long i;
	unsigned char d;
	i=clock();
	while (1) {
		if (clock()>(i+91)) {clrscr();printf("Time out.\n\7\7");exit(1);}
		if ((inp(0x3ed)&1)==1) break;
	}
	d=inp(0x3e8);
	while (!(inportb(0x3ed)&0x20));
	outportb(0x3ed,0x0);
	outportb(0x3e8,d);
	return(d);
}



void select_cpu(unsigned char cpu) {
	long i;
	printf(" Testing CPU ...           ");
	sen_com3(0x0);	/*send start byte*/
	sen_com3(b_cpu);
	sen_com3(cpu);
	if (rec_com3()) {
		fcloseall();
		clrscr();
		printf(" CPU not ready or CPU type error!\n\7\7");
		exit(1);
	}
	printf(" The CPU is %s. \n",cpu_d[cpu]);
}

void init_cpu(void) {
	unsigned char temp;
	printf(" Initialize CPU ...        ");
	sen_com3(0x0);/*send start byte*/
	sen_com3(b_init);
	while (1) {
		temp=rec_com3_long();
		if (temp==0) break;
		else if (temp==1) {
			fcloseall();
			clrscr();
			printf(" Error!\7\n");
			exit(1);
		}
	}
	printf(" Success.\n");
}

void lock_cpu(void) {
	unsigned char temp;
	printf(" Lock CPU ...              ");
	sen_com3(0);	/*send start byte*/
	sen_com3(b_lock123);
	while (1) {
		temp=rec_com3_long();
		if (temp==0) break;
		else if (temp==1) {
			fcloseall();
			clrscr();
			printf(" Error!\7\n");
			exit(1);
		}
	}
	printf(" Success.\n                Total used  %3.2f seconds.\n\7",(clock()-start_time)/18.2);
}


void program(void) {
	unsigned char y,d;
	unsigned int lenth;
	long i;

	fseek(fp1,0,SEEK_SET);
	printf(" Programing ...            ");
	sen_com3(0);	/*send start btye*/
	sen_com3(b_program_byte);
	y=wherey();
	lenth=0;
	while (! (feof(fp1)) ) {
		d=getc(fp1);
		sen_com3(d);
		if ((lenth%0x100)==0) {
			gotoxy(18,y);printf("%4x BYTE  ",lenth);
		}
		lenth++;
	}
	gotoxy(18,y);printf("%4x BYTE  ",lenth-1);
	i=clock();while (clock()<(i+9)) {}
	gotoxy(28,y);
	printf(" Success.\n");
}


void read_flash(void) {
	unsigned char d,y,b_error;
	unsigned int lenth;
	long i;
	fseek(fp1,0,SEEK_SET);
	printf(" Verifing ...              ");
	sen_com3(0);	/*send start btye*/
	sen_com3(b_read);
	y=wherey();
	lenth=0;b_error=0;
	while (! (feof(fp1)) ) {
		d=getc(fp1);
		if (rec_com3()!=d) {
			b_error=1;
			break;
		}
		if ((lenth%0x100)==0) {
			gotoxy(18,y);printf("%4x BYTE  ",lenth);
		}
		lenth++;
	}
	gotoxy(18,y);printf("%4x BYTE  ",lenth-1);
	i=clock();while (clock()<(i+9)) {}
	gotoxy(28,y);
	if (b_error) {
		printf(" Error!\7\7\n");
		fcloseall();
		exit(1);
	} else {
		printf(" Success.\n");
	}
}


void main(char n,char *d[]) {
	unsigned char cpu;
	long i;
	unsigned char chip;
	switch (n) {
	case 1:
		printf(" Please select file.\n\7");
		exit(1);
		break;
	case 2:
		printf(" Please select CPU type.\n");
		exit(1);
		break;
	case 3:
		printf(" Please select pararmeter.\n");
		exit(1);
		break;
	case 4:
		if ((fp1=fopen(*(d+1),"rb"))==NULL) {
			printf ("  File no found.\n\7\7");
			exit(1);
		}
		for (cpu=0;cpu<6;cpu++) {
			if (strcmp(*(d+2),*(cpu_d+cpu))==0) break;
		}
		if (cpu==6) {
			printf(" CPU tpye error.\n");
			exit(1);
		}
		init_com3();
		start_time=clock();
		select_cpu(cpu);

		switch (d[3][0]) {
		case 'P':
		case 'p':
			program();
			break;
		case 'i':
		case 'I':
			init_cpu();
			break;
		case 'l':
		case 'L':
			lock_cpu();
			break;
		case 'a':
		case 'A':
			init_cpu();
			program();
			read_flash();
			i=clock();while (clock()<(i+9)) {}
			lock_cpu();
			break;
		case 'b':
		case 'B':
			while (1) {
				sen_com3(0x0);	/*send start byte*/
				sen_com3(b_cpu);
				sen_com3(cpu);
				if (rec_com3()==0) {
					i=clock();while (clock()<(i+3)) {}
					sen_com3(0);
					sen_com3(b_cpu);
					sen_com3(cpu);
					if (rec_com3()==0) {
						start_time=clock();
						init_cpu();
						program();
						read_flash();
						i=clock();while (clock()<(i+9)) {}
						lock_cpu();
						printf("     Waiting for next CPU ...\n\n");
						while (1) {
							sen_com3(0);
							sen_com3(b_cpu);
							sen_com3(cpu);
							if (rec_com3()) break;
							i=clock();while (clock()<(i+2)) {}
						}
					}
				}
				i=clock();while (clock()<(i+2)) {}
			}
			break;
		}
		break;
	}
}
