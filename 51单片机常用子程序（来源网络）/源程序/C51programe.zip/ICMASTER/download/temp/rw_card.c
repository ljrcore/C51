
void sen(unsigned char ctrl) {
	SBUF=ctrl;while (!TI) {}
	TI=0;
}
unsigned char rec(void) {
	time=0;
	while (!RI) {if (time>40) return(0);}
	RI=0;
	return(SBUF);
}


bit send_to_card(unsigned char no) {
	unsigned char d,i,j,k,dd;
	no--;
	sen(0xaa);	//�������� 
	if (rec()!=0xaa) return(1);
	sen(no);	//�ͳ�������
	if (rec()!=no) return(1);	//ȷ��
	
	EA=0;TR2=1;
	for (k=0;k<4;k++) {
		my_s24();my_wd24(0xa0|(k<<1));scl=0;my_wd24(0);scl=0;my_wd24(0);scl=0;
		my_s24();my_wd24(0xa1|(k<<1));scl=0;
		d=my_rd24_ack();
		for (i=0;i<64;i++) {
			j=0;
			do {
				TI=0;
				SBUF=d;
				dd=my_rd24_ack();
				time=0;
				while (!RI) {
					if (TH2>200) {
						TH2=0;
						if ((++time)>40) {my_p24();EA=1;TR2=0;return(1);}
					}
				}
				RI=0;
				if (SBUF!=d) {my_p24();EA=1;TR2=0;return(1);}
				d=dd;
				j++;
			} while (j);
		}
		d=my_rd24();
		my_p24();
	}
	EA=1;TR2=0;
	return(0);
}

unsigned char idata buf[32];

bit write_buf(unsigned int as) {
	unsigned char e=0,i;
	while (e<3) {
		my_s24();my_wd24(0xa0|((as/16384)<<1));scl=0;my_wd24(as/256);scl=0;my_wd24(as);scl=0;
		for (i=0;i<32;i++) {my_wd24(buf[i]);scl=0;}
		my_p24();
		time=0;
		while (1) {
			my_s24();
			my_wd24(0xa0|((as/16384)<<1));
			sda=1;
			if (sda==0) break;
			if (time>10) break;
			scl=0;
		}
		scl=0;
		for (i=0;i<32;i++) {
			if (my_read(as+i)!=buf[i]) break;
		}
		if (i==32) return(0);
		e++;
	}
	return(1);
}

bit rec_from_card(unsigned char no) {
	unsigned int as;
	unsigned char d,i;
	no--;
	sen(0x55);	//ask for rec
	if (rec()!=0x55) return(1);
	sen(no);
	if (rec()!=no) return(1);
	REN=1;
	as=0;
	do {
		for (i=0;i<32;i++) {
			d=rec();
			if (time>40) return(1);
			TI=0;
			SBUF=d;
			buf[i]=d;
		}
		if (write_buf(as)) return(1);
		as+=32;
	} while (as);
	return(0);
}

