#include <reg51.h>
#include <intrins.h>

sbit GND_LCD=P1^7;
sbit rs=P1^0;
sbit rw=P1^1;
sbit e=P1^2;

unsigned char busy(void);
void ctrl(unsigned char);
void wd_h(unsigned char);
void wd_l(unsigned char);
unsigned char rd(void);
void write(unsigned char);
void init(void);
void NOP(void);

void disp(unsigned char);


unsigned int time;

void int_t0 (void) interrupt 1 {
	TL0=TL0+30;TH0=0xfb;
	time++;
}

void wait(unsigned int w){	
	time=0;
	while (time<w) {}
}


void init(void) {
	unsigned char i;
	P1=0;
	for (i=0;i<2;i++) {
		wd_l(0x30);
		wait(5);
	}
	wd_h(0x20);
	ctrl(0x28);
	ctrl(0x8);
	ctrl(3);
	ctrl(6);
	disp(0);
	ctrl(1);
	ctrl(8);
	ctrl(0xe);
	ctrl(0x80);
}


unsigned char busy(void){
	P1=0;
	return(rd());
}

unsigned char rd(void) {
	unsigned char dat0,dat1;
	rw=1;
	rs=0;
	P1=P1|0x78;
	e=1;
	dat0=P1;
	e=0;
	e=1;
	dat1=P1;
	P1=0;
	return(((dat0<<1)&0xf0) | ((dat1>>3)&0xf) );
}

void ctrl(unsigned char dat){
	while (busy()>0x7f) {};
	rw=rs=0;
	wd_h(dat);
	wd_l(dat);
}
void wd_h(unsigned char dat){
	e=1;
	P1=P1|((dat&0xf0)>>1);
	e=0;
	P1=P1&0x87;
}
void wd_l(unsigned char dat){
	e=1;
	P1=P1|((dat&0xf)<<3);
	e=0;
	P1=0;
}
void write(unsigned char dat) {
	while (busy()>0x7f) {};
	rw=0;
	rs=1;
	wd_h(dat);
	wd_l(dat);
}

//===================================================
void disp(unsigned char i) {
	unsigned char j;
	ctrl(1);
	ctrl(0x80);
	for (j=0;j<6;j++) write(d[i][j]);
	write(' ');
	ctrl(0xc0);
	write('-');
	write('-');
	write('-');
	write('-');
	write('-');
	write('-');
	write('k');
	write('m');
}


