//ht9200b��������

sbit a0=ACC^0;
sbit a1=ACC^1;
sbit a2=ACC^2;
sbit a3=ACC^3;
sbit a4=ACC^4;
sbit a5=ACC^5;
sbit a6=ACC^6;
sbit a7=ACC^7;

sbit dtmf_dat=P2^6;
sbit dtmf_clk=P2^7;
sbit dtmf_ce=P2^4;
void out_dtmf(unsigned char dd) {	
	ACC=dd;
	dtmf_dat=a0;dtmf_clk=0;dtmf_clk=1;
	dtmf_dat=a1;dtmf_clk=0;dtmf_clk=1;
	dtmf_dat=a2;dtmf_clk=0;dtmf_clk=1;
	dtmf_dat=a3;dtmf_clk=0;dtmf_clk=1;
	dtmf_dat=a4;dtmf_clk=0;dtmf_clk=1;
}
