/*	89C51ϵ��CPU���������CPU����*/

#include <reg51.h>
#include <intrins.h>
#include <absacc.h>

#define e 8
#define p 9
#define l 10

sbit led=P3^2;
sbit p27=P2^7;
sbit p26=P2^6;
sbit p36=P3^6;
sbit p37=P3^7;
sbit rst=P3^3;
sbit ale=P3^5;
sbit vpp=P3^4;

bit b_break;
unsigned int adds;


//	13.8mS
void int_t0(void) interrupt 1 {
	TH0=-100;
	b_break=1;
}

void wait(unsigned char w) {
	unsigned int t=w*184;
	b_break=0;
	TL0=-t%256-1;TH0=-t/256;
	while (b_break==0) {}
}

void nop(void) {
	_nop_();_nop_();_nop_();_nop_();
	_nop_();_nop_();_nop_();_nop_();
	_nop_();_nop_();_nop_();_nop_();
	_nop_();_nop_();_nop_();_nop_();
	_nop_();_nop_();_nop_();_nop_();
}

unsigned char command(void) {
	TH0=-100;b_break=0;
	while (RI==0) {if (b_break==1) return(0);}
	RI=0;
	return(SBUF);
}

void earsure(unsigned char cpu) {
	switch (cpu) {
	case 1:		//89C51
	case 2:rst=p26=1;p27=p36=p37=0;nop();vpp=1;nop();
		ale=0;wait(110);ale=1;nop();
		break;
	case 3:
	case 4:break;
	case 5:
	case 6:break;
	}
}

void program(unsigned char cpu) {
	unsigned int bdata adds=0;
	unsigned char d;
	switch (cpu) {
	case 1:	//89C51
	case 2:
		p36=p37=1;rst=1;
		while (1) {
			TH0=-100;b_break=0;
			while (RI==0) {if (b_break==1) return;}
			RI=0;
			d=SBUF;
			//address
			P0=adds%256;
			P2=adds/256;
			p27=1;
			//data
			P1=d;
			nop();	//48clcl
			//vpp
			vpp=1;
			nop();	//48clcl
			//ale
			ale=0;
			wait(1);//100uS
			ale=1;
			nop();	//10uS
			vpp=0;
			nop();	//48clcl
			p27=0;
			nop();	//48clcl
			P1=0xff;
			TH0=-100;b_break=0;
			while (d!=P1) {if (b_break==1) return;}	//data polling
			SBUF=d;
			adds++;
		}
		break;
	case 3:
	case 4:
	case 5:
	case 6:break;
	}
}

void lock(unsigned char cpu) {
	unsigned char i;
	switch (cpu) {
	case 1:	//89c51
	case 2:
		//lock 1
		rst=p26=p36=p27=p37=1;nop();
		vpp=1;
		nop();
		ale=0;
	//	for (i=0;i<6;i++) wait(100);
		wait(1);
		ale=1;
		nop();
		vpp=0;
		nop();
	
		//lock 2
		rst=p26=p27=1;p36=p37=0;nop();
		vpp=1;
		nop();
		ale=0;
	//	for (i=0;i<6;i++) wait(100);
		wait(1);
		ale=1;
		nop();
		vpp=0;
		nop();
		
		//lock 3
		rst=p26=p36=1;p27=p37=0;nop();
		vpp=1;
		nop();
		ale=0;
	//	for (i=0;i<6;i++) wait(100);
		wait(1);
		ale=1;
		nop();
		vpp=0;
		nop();
		break;
	case 3:
	case 4:
	case 5:
	case 6:break;
	}
}

void main(void) {
	unsigned char disp,flash,temp,cpu;
	EA=1;
	SCON=0xd8;PCON=0x80;
	TMOD=0x21;
	TL1=TH1=0xff;TR1=1;
	TH0=-100;ET0=TR0=1;

	flash=0x80;




	while (1) {
		temp=command();
		switch (temp) {
		case 0:
		case 1:		//89c51
		case 2:		//89C52
		case 3:		//80f51
		case 4:		//80F52
		case 5:		//87F51
		case 6:cpu=temp;SBUF=temp;break;//87f52
		case e:SBUF=temp;earsure(cpu);break;	//erasure
		case p:SBUF=temp;program(cpu);break;	//program
		case l:lock(cpu);SBUF=temp;break;	//lock
		default:SBUF=temp;break;
		}
		b_break=0;
		if ((++disp)>flash) {disp=0;led=!led;}
	}
}
	