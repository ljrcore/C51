//89C51ϵ��CPU�������80F51,87F51
#include "stdio.h"
#include "dos.h"
#include "process.h"
#include "string.h"

#define e 8
#define p 9
#define l 10

void init_com1(void) {
	outportb(0x3eb,0x80);
	outportb(0x3e8,1);
	outportb(0x3e9,0x0);
	outportb(0x3eb,0x3);
}

void comm(unsigned char d) {
	unsigned long int i;
	while (!(inportb(0x3ed)&0x20));
	outp(0x3ed,0x0);
	outportb(0x3e8,d);
	i=0;
	while (1) {
		if ((++i)>60000) {printf("time out.\n");exit(1);}
		if ((inp(0x3ed)&0x1)==1) break;
	}
	if (inp(0x3e8)!=d) {printf("CRC error.\n");exit(1);}
}

void program(FILE *fp1,unsigned char cpu) {
	unsigned char y;
	unsigned int lenth=0;
	printf("Program...");
	y=wherey();
	comm(cpu);
	comm(p);
	while (! (feof(fp1)) ) {
		lenth++;
		comm(getc(fp1));
		if ((lenth%0x100)==0) {
			gotoxy(20,y);printf("%x ",lenth);
		}
	}
	gotoxy(20,y);printf("%x ",lenth);
	printf("  ok.\n\7");
}
void earsure(unsigned char cpu) {
	printf("Earsure...");
	comm(cpu);
	comm(e);
	printf("  ok.\n");
}
void lock(unsigned char cpu) {
	unsigned long int i;
	printf("Lock...");
	comm(cpu);
	for (i=0;i<1000000;i++) {}
	comm(l);
	printf("  ok.\n");
}



void main(char n,char *d[]) {
	unsigned char cpu;
	unsigned char *cpu_d[]={{"89c51"},{"89C51"},{"80f51"},{"80F51"},{"87f51"},{"87F51"}};
	FILE *fp1;
	switch (n) {
	case 1:
		printf("File name error.\n");
		exit(1);
		break;
	case 2:
		printf("NO select CPU.\n");
		exit(1);
		break;
	case 3:
		printf("No pararmeter.\n");
		exit(1);
		break;
	case 4:
		if ((fp1=fopen(*(d+1),"rb"))==NULL) {
			printf ("File no found.\n");
			exit(1);
		}
		for (cpu=1;cpu<7;cpu++) {
			if (strcmp(*(d+2),*(cpu_d+cpu-1))==0) break;
		}
		if (cpu==7) {
			printf("CPU tpye error.\n");
			exit(1);
		}
		init_com1();
		switch (d[3][0]) {
		case 'P':
		case 'p':
			program(fp1,cpu);
			break;
		case 'e':
		case 'E':
			earsure(cpu);
			break;
		case 'l':
		case 'L':
			lock(cpu);
			break;
		case 'a':
		case 'A':
			earsure(cpu);
			printf("\n");
			program(fp1,cpu);
			printf("\n");
			lock(cpu);
			break;
		}
		break;
	}
	exit(1);
}
