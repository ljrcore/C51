//HT1380ʵʱʱ����������

sbit clock_dat=P0^1;
sbit clock_clk=P0^2;
sbit clock_rst=P0^3;

sbit a0=ACC^0;
sbit a1=ACC^1;
sbit a2=ACC^2;
sbit a3=ACC^3;
sbit a4=ACC^4;
sbit a5=ACC^5;
sbit a6=ACC^6;
sbit a7=ACC^7;

void clock_out(unsigned char dd) {
	ACC=dd;
	clock_dat=a0;clock_clk=1;clock_clk=0;
	clock_dat=a1;clock_clk=1;clock_clk=0;
	clock_dat=a2;clock_clk=1;clock_clk=0;
	clock_dat=a3;clock_clk=1;clock_clk=0;
	clock_dat=a4;clock_clk=1;clock_clk=0;
	clock_dat=a5;clock_clk=1;clock_clk=0;
	clock_dat=a6;clock_clk=1;clock_clk=0;
	clock_dat=a7;clock_clk=1;clock_clk=0;
}
unsigned char clock_in(void) {
	clock_dat=1;
	a0=clock_dat;
	clock_clk=1;clock_clk=0;a1=clock_dat;
	clock_clk=1;clock_clk=0;a2=clock_dat;
	clock_clk=1;clock_clk=0;a3=clock_dat;
	clock_clk=1;clock_clk=0;a4=clock_dat;
	clock_clk=1;clock_clk=0;a5=clock_dat;
	clock_clk=1;clock_clk=0;a6=clock_dat;
	clock_clk=1;clock_clk=0;a7=clock_dat;
	return(ACC);
}
unsigned char read_clock(unsigned char ord) {
	unsigned char dd=0;
	clock_clk=0;
	clock_rst=0;
	clock_rst=1;
	clock_out(ord);
	dd=clock_in();
	clock_rst=0;
	clock_clk=1;
	return(dd);
}
void write_clock(unsigned char ord,unsigned char dd) {
	clock_clk=0;
	clock_rst=0;
	clock_rst=1;
	clock_out(ord);
	clock_out(dd);
	clock_rst=0;
	clock_clk=1;
}

